(() => {
  // Configuração central dos CTAs do WhatsApp: mantenha o número sem símbolos
  // e a mensagem neste único local. A pessoa revisa e envia no próprio app.
  const WHATSAPP_PHONE = "5522936181686";
  const WHATSAPP_MESSAGE =
    "Olá, Clara! Gostaria de saber mais sobre o acompanhamento nutricional.";
  const buildWhatsAppUrl = (message) =>
    `https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(message)}`;
  const whatsappUrl = buildWhatsAppUrl(WHATSAPP_MESSAGE);

  // Cole aqui somente a URL oficial do perfil real. Vazio = nenhum link externo.
  const INSTAGRAM_PROFILE_URL = "";
  const instagramPlaceholder = document.querySelector("#instagram-placeholder");
  if (INSTAGRAM_PROFILE_URL.trim()) {
    let profileUrl;
    try {
      profileUrl = new URL(INSTAGRAM_PROFILE_URL.trim());
    } catch {
      console.error("Configure uma URL válida de perfil do Instagram.");
    }

    const profilePath = profileUrl?.pathname.split("/").filter(Boolean) ?? [];
    const validInstagramProfile =
      profileUrl?.protocol === "https:" &&
      ["instagram.com", "www.instagram.com"].includes(profileUrl.hostname) &&
      profilePath.length === 1 &&
      !profileUrl.search &&
      !profileUrl.hash;

    if (validInstagramProfile) {
      const link = document.createElement("a");
      link.className = "instagram-link";
      link.href = profileUrl.href;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.setAttribute("aria-label", "Abrir perfil do Instagram em nova aba");
      link.append(document.createTextNode("Instagram "));
      const arrow = document.createElement("span");
      arrow.setAttribute("aria-hidden", "true");
      arrow.textContent = "↗";
      link.append(arrow);
      instagramPlaceholder.replaceWith(link);
    } else if (profileUrl) {
      console.error(
        "A URL do Instagram deve apontar diretamente para um perfil HTTPS.",
      );
    }
  }

  document.querySelectorAll("[data-whatsapp-cta]").forEach((link) => {
    link.href = whatsappUrl;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
  });

  const siteHeader = document.querySelector(".site-header");
  const menuButton = document.querySelector(".menu-toggle");
  const siteNav = document.querySelector("#site-nav");
  const closeButton = document.querySelector(".drawer-close");
  const backdrop = document.querySelector(".nav-backdrop");
  const mobileNavQuery = window.matchMedia("(max-width: 680px)");
  const reducedMotionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
  const backgroundElements = [
    document.querySelector(".skip-link"),
    document.querySelector(".header-inner > .brand"),
    document.querySelector("#conteudo"),
    document.querySelector(".site-footer"),
    document.querySelector(".whatsapp-float"),
    menuButton,
  ].filter(Boolean);

  let drawerOpen = false;
  let lockedScrollY = 0;

  function applyDrawerState() {
    menuButton.setAttribute("aria-expanded", String(drawerOpen));
    menuButton.setAttribute(
      "aria-label",
      drawerOpen ? "Fechar menu de navegação" : "Abrir menu de navegação",
    );
    siteNav.classList.toggle("is-open", drawerOpen);

    if (mobileNavQuery.matches) {
      siteNav.setAttribute("role", "dialog");
      siteNav.setAttribute("aria-modal", "true");
      siteNav.setAttribute("aria-labelledby", "nav-drawer-title");
      siteNav.setAttribute("aria-hidden", String(!drawerOpen));
      siteNav.inert = !drawerOpen;
      backdrop.hidden = !drawerOpen;
      document.documentElement.classList.toggle("drawer-open", drawerOpen);
      backgroundElements.forEach((element) => {
        element.inert = drawerOpen;
      });
      return;
    }

    siteNav.removeAttribute("role");
    siteNav.removeAttribute("aria-modal");
    siteNav.removeAttribute("aria-labelledby");
    siteNav.removeAttribute("aria-hidden");
    siteNav.inert = false;
    backdrop.hidden = true;
    document.documentElement.classList.remove("drawer-open");
    backgroundElements.forEach((element) => {
      element.inert = false;
    });
  }

  function lockPageScroll() {
    lockedScrollY = window.scrollY;
    document.body.style.position = "fixed";
    document.body.style.top = `-${lockedScrollY}px`;
    document.body.style.left = "0";
    document.body.style.right = "0";
    document.body.style.width = "100%";
    document.body.style.overflow = "hidden";
  }

  function unlockPageScroll() {
    document.body.style.position = "";
    document.body.style.top = "";
    document.body.style.left = "";
    document.body.style.right = "";
    document.body.style.width = "";
    document.body.style.overflow = "";
    window.scrollTo(0, lockedScrollY);
  }

  function openDrawer() {
    if (!mobileNavQuery.matches || drawerOpen) return;
    lockPageScroll();
    drawerOpen = true;
    applyDrawerState();
    requestAnimationFrame(() => closeButton.focus());
  }

  function closeDrawer(returnFocus = false) {
    if (!drawerOpen) return;
    drawerOpen = false;
    applyDrawerState();
    unlockPageScroll();
    if (returnFocus) menuButton.focus();
  }

  menuButton.addEventListener("click", () => {
    if (drawerOpen) closeDrawer();
    else openDrawer();
  });
  closeButton.addEventListener("click", () => closeDrawer(true));
  backdrop.addEventListener("click", () => closeDrawer(true));

  siteNav.addEventListener("click", (event) => {
    const link =
      event.target instanceof Element ? event.target.closest("a[href]") : null;
    if (!link || !mobileNavQuery.matches) return;

    const destination = link.getAttribute("href");
    if (destination.startsWith("#") && destination.length > 1) {
      const target = document.getElementById(destination.slice(1));
      if (!target) {
        closeDrawer();
        return;
      }

      event.preventDefault();
      closeDrawer();
      history.pushState(null, "", destination);
      requestAnimationFrame(() => {
        target.setAttribute("tabindex", "-1");
        target.focus({ preventScroll: true });
        target.scrollIntoView({
          behavior: reducedMotionQuery.matches ? "auto" : "smooth",
          block: "start",
        });
      });
      return;
    }

    closeDrawer();
  });

  document.addEventListener("keydown", (event) => {
    if (!drawerOpen) return;

    if (event.key === "Escape") {
      event.preventDefault();
      closeDrawer(true);
      return;
    }

    if (event.key !== "Tab") return;
    const focusable = Array.from(
      siteNav.querySelectorAll('a[href], button:not([disabled])'),
    );
    const first = focusable[0];
    const last = focusable[focusable.length - 1];

    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });

  mobileNavQuery.addEventListener("change", () => {
    if (!mobileNavQuery.matches && drawerOpen) closeDrawer();
    applyDrawerState();
  });
  applyDrawerState();

  let headerFrame = 0;
  function updateHeaderOnScroll() {
    if (headerFrame) return;
    headerFrame = requestAnimationFrame(() => {
      siteHeader.classList.toggle("is-scrolled", window.scrollY > 24);
      headerFrame = 0;
    });
  }
  window.addEventListener("scroll", updateHeaderOnScroll, { passive: true });
  updateHeaderOnScroll();

  const revealElements = document.querySelectorAll(
    [
      ".hero-copy",
      ".hero-visual",
      ".manifesto",
      ".about-image-wrap",
      ".about-copy",
      ".section-heading",
      ".service-card",
      ".food-photo",
      ".food-quote",
      ".process-heading",
      ".steps li",
      ".testimonial-top",
      ".testimonials h2",
      ".testimonial",
      ".faq-intro",
      ".faq-item",
      ".contact-copy",
      ".contact-form",
      ".footer-top",
      ".footer-bottom",
    ].join(","),
  );
  revealElements.forEach((element) => element.setAttribute("data-reveal", ""));

  let revealObserver;
  function setupReveals() {
    if (revealObserver) revealObserver.disconnect();

    if (reducedMotionQuery.matches || !("IntersectionObserver" in window)) {
      document.documentElement.classList.remove("motion-ready");
      revealElements.forEach((element) => element.classList.add("is-visible"));
      return;
    }

    document.documentElement.classList.add("motion-ready");
    revealElements.forEach((element) => element.classList.remove("is-visible"));
    revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          entry.target.classList.toggle("is-visible", entry.isIntersecting);
        });
      },
      { threshold: 0.14, rootMargin: "0px 0px -5% 0px" },
    );
    revealElements.forEach((element) => revealObserver.observe(element));
  }

  const parallaxImages = document.querySelectorAll(
    ".hero-visual .portrait-frame img, .food-photo img",
  );
  const desktopQuery = window.matchMedia("(min-width: 681px)");
  let parallaxEnabled = false;
  let parallaxFrame = 0;

  function updateParallax() {
    if (!parallaxEnabled || parallaxFrame) return;
    parallaxFrame = requestAnimationFrame(() => {
      const viewportHeight = window.innerHeight || 1;
      parallaxImages.forEach((image) => {
        const rect = image.getBoundingClientRect();
        if (rect.bottom < 0 || rect.top > viewportHeight) return;
        const centerOffset =
          (rect.top + rect.height / 2 - viewportHeight / 2) / viewportHeight;
        const offset = Math.max(-7, Math.min(7, -centerOffset * 10));
        image.style.setProperty("--parallax-y", `${offset.toFixed(2)}px`);
      });
      parallaxFrame = 0;
    });
  }

  function setupParallax() {
    const shouldEnable =
      desktopQuery.matches && !reducedMotionQuery.matches && parallaxImages.length > 0;
    if (shouldEnable === parallaxEnabled) return;
    parallaxEnabled = shouldEnable;

    if (parallaxEnabled) {
      window.addEventListener("scroll", updateParallax, { passive: true });
      window.addEventListener("resize", updateParallax, { passive: true });
      updateParallax();
      return;
    }

    window.removeEventListener("scroll", updateParallax);
    window.removeEventListener("resize", updateParallax);
    if (parallaxFrame) cancelAnimationFrame(parallaxFrame);
    parallaxFrame = 0;
    parallaxImages.forEach((image) => image.style.removeProperty("--parallax-y"));
  }

  setupReveals();
  setupParallax();

  const floatingButton = document.querySelector(".whatsapp-float");
  const floatingContent = document.querySelectorAll(
    [
      "main h1",
      "main h2",
      "main h3",
      "main p",
      "main li",
      "main blockquote",
      "main figcaption",
      "main img",
      "main a",
      "main button",
      "main input",
      "main textarea",
      ".hero-stamp",
      ".portrait-caption",
      ".photo-note",
      ".image-credit",
      ".site-footer p",
      ".site-footer a",
    ].join(","),
  );
  let floatingOverlapObserver;

  function setupFloatingAvoidance() {
    if (floatingOverlapObserver) floatingOverlapObserver.disconnect();
    if (!("IntersectionObserver" in window)) {
      floatingButton.classList.add("is-obscured");
      return;
    }

    const rect = floatingButton.getBoundingClientRect();
    const rootMargin = [
      `${-Math.ceil(rect.top)}px`,
      `${-Math.ceil(window.innerWidth - rect.right)}px`,
      `${-Math.ceil(window.innerHeight - rect.bottom)}px`,
      `${-Math.ceil(rect.left)}px`,
    ].join(" ");
    floatingOverlapObserver = new IntersectionObserver(
      (entries) => {
        const overlapsContent = entries.some((entry) => entry.isIntersecting);
        if (overlapsContent) {
          floatingContent.forEach((element) => {
            if (
              element.getBoundingClientRect().right > rect.left &&
              element.getBoundingClientRect().left < rect.right &&
              element.getBoundingClientRect().bottom > rect.top &&
              element.getBoundingClientRect().top < rect.bottom
            ) {
              element.dataset.overlapsFloatingCta = "true";
            }
          });
        } else {
          floatingContent.forEach((element) => {
            delete element.dataset.overlapsFloatingCta;
          });
        }
        floatingButton.classList.toggle("is-obscured", overlapsContent);
      },
      { rootMargin, threshold: 0 },
    );
    floatingContent.forEach((element) => floatingOverlapObserver.observe(element));
  }

  window.addEventListener("resize", setupFloatingAvoidance, { passive: true });
  setupFloatingAvoidance();

  reducedMotionQuery.addEventListener("change", () => {
    setupReveals();
    setupParallax();
  });
  desktopQuery.addEventListener("change", setupParallax);

  document.querySelectorAll(".faq-question").forEach((button) => {
    button.addEventListener("click", () => {
      const wasExpanded = button.getAttribute("aria-expanded") === "true";
      const panel = document.getElementById(button.getAttribute("aria-controls"));
      button.setAttribute("aria-expanded", String(!wasExpanded));
      panel.hidden = wasExpanded;
    });
  });

  const form = document.querySelector("#contact-form");
  const demoSubmitButton = document.querySelector("#demo-form-submit");
  const status = document.querySelector("#form-status");
  const statusMessage = document.querySelector("#form-status-message");
  const fields = [
    { input: document.querySelector("#nome"), error: document.querySelector("#nome-erro"), label: "nome" },
    { input: document.querySelector("#email"), error: document.querySelector("#email-erro"), label: "e-mail" },
    { input: document.querySelector("#mensagem"), error: document.querySelector("#mensagem-erro"), label: "mensagem" },
  ];

  function validateField(field) {
    const value = field.input.value.trim();
    let message = "";
    if (!value) message = `Por favor, preencha ${field.label}.`;
    else if (
      field.input.type === "email" &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)
    ) {
      message = "Informe um e-mail em formato válido.";
    }
    field.error.textContent = message;
    field.input.setAttribute("aria-invalid", String(Boolean(message)));
    return !message;
  }

  fields.forEach(({ input }) => {
    input.addEventListener("blur", () =>
      validateField(fields.find((field) => field.input === input)),
    );
    input.addEventListener("input", () => {
      if (input.getAttribute("aria-invalid") === "true") {
        validateField(fields.find((field) => field.input === input));
      }
      status.hidden = true;
    });
    if (input.tagName === "INPUT") {
      input.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          form.requestSubmit();
        }
      });
    }
  });

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const valid = fields.map(validateField).every(Boolean);
    statusMessage.textContent =
      "Formulário demonstrativo: nenhuma mensagem será enviada e nenhum dado será armazenado.";
    status.hidden = false;
    if (!valid) {
      fields.find((field) => field.input.getAttribute("aria-invalid") === "true").input.focus();
      return;
    }
    status.focus();
  });

  demoSubmitButton.addEventListener("click", () => form.requestSubmit());

  document.querySelector("#current-year").textContent = new Date().getFullYear();
})();
